
HOPE FOUNDATION WEBSITE

Files Included:
- index.html
- style.css

How to Run:
1. Extract the ZIP file.
2. Open index.html in any browser.
3. Customize text, pictures, and donation details if needed.

Project Features:
- Charity homepage
- Donation plans
- Invite/referral link
- Leadership section
- Contact email
- Responsive design
